module Helpers where

import Data.List

maybeRead :: Read a => String -> Maybe a
maybeRead s = case reads s of
                [(x, "")] -> Just x
                otherwise -> Nothing

readInt :: String -> Maybe Integer
readInt = maybeRead

readFloat :: String -> Maybe Float
readFloat = maybeRead

readBool :: String -> Maybe Bool
readBool = maybeRead

-- input a list of list, output the list all lists' head
headList :: [[a]] -> [a]
headList []     = []
headList (x:xs) = (head x):(headList xs)

-- input a list of list, output the list all lists' head
tailList :: [[a]] -> [[a]]
tailList []     = []
tailList (x:xs) = (tail x):(tailList xs)

isEmptyLists :: [[a]] -> Bool
isEmptyLists []     = True
isEmptyLists (x:xs) = isEmptyLists xs && null x

doubleListRotate :: [[a]] -> [[a]]
doubleListRotate xs = case isEmptyLists xs of
                        True  -> []
                        False -> (headList xs) : (doubleListRotate (tailList xs))

fstList :: [(a, b)] -> [a]
fstList [] = []
fstList ((x,y):ls) = x : (fstList ls)

sndList :: [(a, b)] -> [b]
sndList [] = []
sndList ((x,y):ls) = y : (sndList ls)

fst3 :: (a, b, c) -> a
fst3 (x, _, _) = x

snd3 :: (a, b, c) -> b
snd3 (_, x, _) = x

thd3 :: (a, b, c) -> c
thd3 (_, _, x) = x

mapTuple :: ((a -> b),(c -> d)) -> [(a,c)] -> [(b,d)]
mapTuple _ []              = []
mapTuple (fl,fr) ((l,r):s) = (fl l,fr r) : mapTuple (fl,fr) s

--give a num n and a list, output the n's element of the list, and the list that del. the n's element
moveEleOut :: Int -> [a] -> (a,[a])
moveEleOut 1 (x:xs) = (x,xs)
moveEleOut i (x:xs) = (fst (moveEleOut (i-1) xs), [x] ++ snd (moveEleOut (i-1) xs))

--This a helper funtion for changeValueByPos. It takes a D list, a column order number, and a target string as input, and output a D list that change the specific string to the target string.
moveEleIn :: Int -> (a,[a]) -> [a]
moveEleIn _ (x,[])     = [x]
moveEleIn 1 (x,ys)     = x:ys
moveEleIn i (x,(y:ys)) = y:moveEleIn (i-1) (x,ys)

merge2 :: [[a]] -> [[a]] -> [[a]]
merge2 xs []         = xs
merge2 [] xs         = xs
merge2 (x:xs) (y:ys) = [x++y] ++ merge2 xs ys

--give list of list, return list
unfold :: [[a]] -> [a]
unfold []     = []
unfold (x:xs) = x ++ unfold xs

--reference: https://hackage.haskell.org/package/either-unwrap-1.1/docs/Data-Either-Unwrap.html
-- | The 'fromRight' function extracts the element out of a 'Right' and
-- throws an error if its argument take the form  @Left _@.
fromRight           :: Either a b -> b
fromRight (Left _)  = error "Either.Unwrap.fromRight: Argument takes form 'Left _'" -- yuck
fromRight (Right x) = x

